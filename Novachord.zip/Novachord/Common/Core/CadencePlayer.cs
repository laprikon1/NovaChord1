using System;
using System.IO;
using Microsoft.Xna.Framework;
using NovaChord.Content.Buffs;
using NovaChord.Content.Items;
using NovaChord.Content.Projectiles;
using Terraria;
using Terraria.Audio;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;

namespace NovaChord.Common.Core
{
    /// <summary>Rarity of a Starfall Finale "constellation draw" (the gacha roll).</summary>
    public enum CadenceRarity : byte
    {
        Common = 0,
        Rare = 1,
        Legendary = 2
    }

    /// <summary>
    ///     Per-player cadence state: attunement, Tempo stacks, the Finale gauge and the
    ///     active Finale sequence. Gameplay values are server-authoritative in multiplayer;
    ///     the owning client mirrors them for the HUD and reconciles via the mod's packets.
    /// </summary>
    public sealed class CadencePlayer : ModPlayer
    {
        // ---- Balance constants -------------------------------------------------------
        public const int TempoCap = 5;
        public const int TempoDuration = 480;          // 8 s, refreshed on each perfect
        public const float GaugeMax = 100f;
        public const float PerfectGaugeGain = 12f;
        public const float OverflowGaugeGain = 4f;
        public const float HitGaugeGain = 1f;
        public const float SigilGainMultiplier = 1.25f;

        public const int MinDraw = 12;                 // ticks before a release does anything
        public const int PerfectStart = 40;            // perfect window opens
        public const int PerfectEnd = 52;              // ...and closes (widened by the sigil)
        public const int MaxDraw = 90;                 // auto-release
        public const int FinaleDuration = 180;

        // ---- Persistent state --------------------------------------------------------
        public Attunement Attunement;
        public int TempoStacks;
        public int TempoTimer;
        public float FinaleGauge;
        public bool FinaleActive;
        public int FinaleTimer;
        public CadenceRarity FinaleRarity;
        public bool SigilEquipped;

        // ---- Client presentation -----------------------------------------------------
        public bool IsDrawing;
        public int DrawTimer;
        public int PerfectFlashTimer;
        public int FinaleBannerTimer;
        private int _lancesSpawned;

        public bool HoldingBow => Player.HeldItem?.type == ModContent.ItemType<StarfallCadence>();

        public int PerfectWindowEnd => PerfectEnd + (SigilEquipped ? 4 : 0);

        public float GainMultiplier => SigilEquipped ? SigilGainMultiplier : 1f;

        public override void ResetEffects()
        {
            SigilEquipped = false;
        }

        public override void PostUpdate()
        {
            if (PerfectFlashTimer > 0)
                PerfectFlashTimer--;
            if (FinaleBannerTimer > 0)
                FinaleBannerTimer--;

            if (!Player.HasBuff(ModContent.BuffType<Tempo>()))
            {
                TempoStacks = 0;
                TempoTimer = 0;
            }

            FinaleGauge = MathHelper.Clamp(FinaleGauge, 0f, GaugeMax);

            if (FinaleActive)
                UpdateFinale();
        }

        // Stat hooks ---------------------------------------------------------------------
        public override StatModifier GetDamage(DamageClass damageClass)
        {
            StatModifier modifier = base.GetDamage(damageClass);
            if (damageClass == DamageClass.Ranged && TempoStacks > 0)
                modifier += 0.04f * TempoStacks;
            return modifier;
        }

        public override float GetTotalAttackSpeed(DamageClass damageClass)
        {
            float speed = base.GetTotalAttackSpeed(damageClass);
            if (damageClass == DamageClass.Ranged && TempoStacks > 0)
                speed += 0.02f * TempoStacks;
            return speed;
        }

        // Keybinds -------------------------------------------------------------------------
        public override void ProcessTriggers()
        {
            if (CadenceKeybinds.CycleAttunement?.JustPressed == true)
            {
                Attunement = Attunement.Next();
                SoundEngine.PlaySound(SoundID.Item12 with { Volume = 0.5f, Pitch = 0.4f }, Player.Center);
                CadenceParticles.Burst(Player.Center, Attunement.Primary(), 8, 2.5f, 10f, 20);
                SendState();
            }

            if (CadenceKeybinds.Finale?.JustPressed == true)
                TryFinale();
        }

        // Perfect release ------------------------------------------------------------------
        /// <summary>Called by the holdout on the owning client when a draw lands in the perfect window.</summary>
        public void OnPerfectRelease()
        {
            TempoStacks = Math.Min(TempoCap, TempoStacks + 1);
            TempoTimer = TempoDuration;
            Player.AddBuff(ModContent.BuffType<Tempo>(), TempoDuration);
            PerfectFlashTimer = 22;

            if (Main.netMode == NetmodeID.MultiplayerClient)
            {
                ModPacket packet = Mod.GetPacket();
                packet.Write((byte)NovaChord.Packet.PerfectRelease);
                packet.Send();
            }
            else
            {
                ServerPerfect(Player.whoAmI);
            }
        }

        /// <summary>Server side: award gauge for a perfect release and relay the celebration.</summary>
        public static void ServerPerfect(int whoAmI)
        {
            Player player = Main.player[whoAmI];
            CadencePlayer cadence = player.GetModPlayer<CadencePlayer>();
            cadence.FinaleGauge = MathHelper.Clamp(cadence.FinaleGauge + PerfectGaugeGain * cadence.GainMultiplier, 0f, GaugeMax);
            cadence.TempoStacks = Math.Min(TempoCap, cadence.TempoStacks + 1);

            if (Main.netMode == NetmodeID.Server)
            {
                ModPacket packet = ModContent.GetInstance<NovaChord>().GetPacket();
                packet.Write((byte)NovaChord.Packet.PerfectRelease);
                packet.Write((byte)whoAmI);
                packet.Write(cadence.FinaleGauge);
                packet.WriteVector2(player.Center);
                packet.Send();
            }
            else
            {
                ClientPerfect(whoAmI, cadence.FinaleGauge, player.Center);
            }
        }

        /// <summary>Client side: perfect-release feedback (chime, sparks, HUD flash).</summary>
        public static void ClientPerfect(int whoAmI, float gauge, Vector2 center)
        {
            Player player = Main.player[whoAmI];
            CadencePlayer cadence = player.GetModPlayer<CadencePlayer>();
            cadence.FinaleGauge = gauge;

            if (whoAmI == Main.myPlayer)
            {
                cadence.PerfectFlashTimer = 22;
                SoundEngine.PlaySound(SoundID.Item29 with { Volume = 0.7f, Pitch = 0.5f }, center);
                CadenceParticles.Burst(center, cadence.Attunement.Secondary(), 16, 5f, 16f, 30);
                CadenceParticles.Burst(center, Color.White, 6, 3f, 10f, 22);
            }
        }

        // Finale ---------------------------------------------------------------------------
        public void TryFinale()
        {
            if (FinaleGauge < GaugeMax || FinaleActive || !HoldingBow || Player.dead)
                return;

            if (Main.netMode == NetmodeID.MultiplayerClient)
            {
                ModPacket packet = Mod.GetPacket();
                packet.Write((byte)NovaChord.Packet.FinaleStart);
                packet.Send();
            }
            else
            {
                ServerFinale(Player.whoAmI);
            }
        }

        /// <summary>Server side: validate, roll the constellation rarity and start the Finale.</summary>
        public static void ServerFinale(int whoAmI)
        {
            Player player = Main.player[whoAmI];
            CadencePlayer cadence = player.GetModPlayer<CadencePlayer>();
            if (cadence.FinaleGauge < GaugeMax || cadence.FinaleActive)
                return;

            CadenceRarity rarity = RollRarity(cadence);
            cadence.FinaleGauge = 0f;
            cadence.FinaleActive = true;
            cadence.FinaleTimer = FinaleDuration;
            cadence.FinaleRarity = rarity;
            player.AddBuff(ModContent.BuffType<Encore>(), FinaleDuration);

            if (Main.netMode == NetmodeID.Server)
            {
                ModPacket packet = ModContent.GetInstance<NovaChord>().GetPacket();
                packet.Write((byte)NovaChord.Packet.FinaleStart);
                packet.Write((byte)whoAmI);
                packet.Write((byte)rarity);
                packet.Send();
            }
            else
            {
                ClientFinale(whoAmI, rarity);
            }
        }

        private static CadenceRarity RollRarity(CadencePlayer cadence)
        {
            // Base odds 70 / 25 / 5; the Encore Sigil and Tempo stacks tilt them upward.
            float common = cadence.SigilEquipped ? 55f : 70f;
            float rare = (cadence.SigilEquipped ? 33f : 25f) + cadence.TempoStacks;
            float legendary = (cadence.SigilEquipped ? 12f : 5f) + cadence.TempoStacks * 0.5f;
            float roll = Main.rand.NextFloat(common + rare + legendary);

            if (roll < common)
                return CadenceRarity.Common;
            if (roll < common + rare)
                return CadenceRarity.Rare;
            return CadenceRarity.Legendary;
        }

        /// <summary>Client side: begin the Finale presentation (banner, ambience, lance schedule).</summary>
        public static void ClientFinale(int whoAmI, CadenceRarity rarity)
        {
            Player player = Main.player[whoAmI];
            CadencePlayer cadence = player.GetModPlayer<CadencePlayer>();
            cadence.FinaleGauge = 0f;
            cadence.FinaleActive = true;
            cadence.FinaleTimer = FinaleDuration;
            cadence.FinaleRarity = rarity;
            cadence._lancesSpawned = 0;

            if (whoAmI == Main.myPlayer)
            {
                cadence.FinaleBannerTimer = 150;
                SoundEngine.PlaySound(SoundID.Item4 with { Volume = 0.9f, Pitch = -0.2f }, player.Center);
                SoundEngine.PlaySound(SoundID.Item29 with { Volume = 0.8f, Pitch = -0.4f }, player.Center);
                if (NovaChordConfig.Instance.CameraEffects)
                    CadenceCamera.Shake(player.Center, rarity == CadenceRarity.Legendary ? 14f : 8f);
                CadenceParticles.Burst(player.Center, cadence.Attunement.Primary(), 30, 7f, 18f, 40);
            }
        }

        private void UpdateFinale()
        {
            FinaleTimer--;

            // The owning client rains lances over the first 120 ticks of the sequence.
            if (Main.netMode != NetmodeID.Server && Player.whoAmI == Main.myPlayer)
            {
                int total = FinaleRarity switch
                {
                    CadenceRarity.Rare => 10,
                    CadenceRarity.Legendary => 14,
                    _ => 6
                };
                int elapsed = FinaleDuration - FinaleTimer;
                int interval = Math.Max(1, 120 / total);
                if (elapsed <= 120 && elapsed % interval == 0 && _lancesSpawned < total)
                {
                    SpawnFinaleLance();
                    _lancesSpawned++;
                }
            }

            if (FinaleTimer <= 0)
            {
                if (FinaleRarity == CadenceRarity.Legendary && Player.whoAmI == Main.myPlayer && Main.netMode != NetmodeID.Server)
                {
                    // Legendary draws end in a radiant nova.
                    CadenceParticles.Burst(Player.Center, Attunement.Secondary(), 46, 11f, 22f, 50);
                    CadenceParticles.Burst(Player.Center, Color.White, 20, 6f, 14f, 36);
                    SoundEngine.PlaySound(SoundID.Item89 with { Volume = 0.9f }, Player.Center);
                    if (NovaChordConfig.Instance.CameraEffects)
                        CadenceCamera.Shake(Player.Center, 16f);
                }

                FinaleActive = false;
                _lancesSpawned = 0;
            }
        }

        private void SpawnFinaleLance()
        {
            Vector2 target = Main.MouseWorld;
            Vector2 spawn = target + new Vector2(Main.rand.NextFloat(-320f, 320f), Main.rand.NextFloat(-760f, -560f));
            Vector2 velocity = (target - spawn).SafeNormalize(Vector2.UnitY) * 16f;
            int damage = (int)(Player.GetDamage(DamageClass.Ranged).ApplyTo(70) * 1.5f);
            float homing = FinaleRarity == CadenceRarity.Legendary ? 1f : 0f;

            IEntitySource source = Player.GetSource_ItemUse(Player.HeldItem);
            Projectile.NewProjectile(source, spawn, velocity, ModContent.ProjectileType<StarfallLance>(),
                damage, 5f, Player.whoAmI, target.X, target.Y, homing);
        }

        // Gauge helpers ----------------------------------------------------------------------
        /// <summary>Server side: add gauge (from hits/overflows) and push the value to the owner.</summary>
        public void AddGauge(float amount)
        {
            FinaleGauge = MathHelper.Clamp(FinaleGauge + amount * GainMultiplier, 0f, GaugeMax);
            ResonanceSystem.SendGauge(Player.whoAmI, FinaleGauge);
        }

        // Networking ---------------------------------------------------------------------------
        public void SendState()
        {
            if (Main.netMode == NetmodeID.MultiplayerClient)
            {
                ModPacket packet = Mod.GetPacket();
                packet.Write((byte)NovaChord.Packet.PlayerState);
                WriteState(packet);
                packet.Send();
            }
            else if (Main.netMode == NetmodeID.Server)
            {
                ModPacket packet = Mod.GetPacket();
                packet.Write((byte)NovaChord.Packet.PlayerState);
                packet.Write((byte)Player.whoAmI);
                WriteState(packet);
                packet.Send(ignoreClient: Player.whoAmI);
            }
        }

        private void WriteState(ModPacket packet)
        {
            packet.Write((byte)Attunement);
            packet.Write((byte)TempoStacks);
            packet.Write(FinaleGauge);
            packet.Write(FinaleActive);
            packet.Write((byte)FinaleRarity);
        }

        public override void SyncPlayer(int toWho, int fromWho, bool newPlayer)
        {
            if (Main.netMode == NetmodeID.Server)
            {
                ModPacket packet = Mod.GetPacket();
                packet.Write((byte)NovaChord.Packet.PlayerState);
                packet.Write((byte)Player.whoAmI);
                WriteState(packet);
                packet.Send(toWho, fromWho);
            }
        }

        /// <summary>Handle a PlayerState packet (both directions).</summary>
        public static void ReceiveState(BinaryReader reader, int whoAmI)
        {
            if (Main.netMode == NetmodeID.Server)
            {
                int playerIndex = whoAmI;
                CadencePlayer cadence = Main.player[playerIndex].GetModPlayer<CadencePlayer>();
                cadence.Attunement = (Attunement)reader.ReadByte();
                cadence.TempoStacks = reader.ReadByte();
                reader.ReadSingle(); // client gauge is ignored; server is authoritative
                reader.ReadBoolean();
                reader.ReadByte();
                cadence.SendState();
            }
            else
            {
                int playerIndex = reader.ReadByte();
                CadencePlayer cadence = Main.player[playerIndex].GetModPlayer<CadencePlayer>();
                cadence.Attunement = (Attunement)reader.ReadByte();
                cadence.TempoStacks = reader.ReadByte();
                cadence.FinaleGauge = reader.ReadSingle();
                cadence.FinaleActive = reader.ReadBoolean();
                cadence.FinaleRarity = (CadenceRarity)reader.ReadByte();
            }
        }

        /// <summary>Handle a PerfectRelease packet (both directions).</summary>
        public static void ReceivePerfect(BinaryReader reader, int whoAmI)
        {
            if (Main.netMode == NetmodeID.Server)
            {
                ServerPerfect(whoAmI);
            }
            else
            {
                int playerIndex = reader.ReadByte();
                float gauge = reader.ReadSingle();
                Vector2 center = reader.ReadVector2();
                ClientPerfect(playerIndex, gauge, center);
            }
        }

        /// <summary>Handle a FinaleStart packet (both directions).</summary>
        public static void ReceiveFinale(BinaryReader reader, int whoAmI)
        {
            if (Main.netMode == NetmodeID.Server)
            {
                ServerFinale(whoAmI);
            }
            else
            {
                int playerIndex = reader.ReadByte();
                CadenceRarity rarity = (CadenceRarity)reader.ReadByte();
                ClientFinale(playerIndex, rarity);
            }
        }
    }
}
