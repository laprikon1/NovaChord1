using Microsoft.Xna.Framework;
using NovaChord.Content.Particles;
using ParticleLibrary.Core;
using ParticleLibrary.Core.V3;
using ParticleLibrary.Core.V3.Particles;
using Terraria;
using Terraria.ModLoader;
using NumericsVector2 = System.Numerics.Vector2;

namespace NovaChord.Common.Core
{
    /// <summary>
    ///     High volume, cheap particle work (sparks, motes, drifting embers) is handed to
    ///     Particle Library's instanced V3 buffers instead of Terraria dust or a bespoke renderer.
    ///     Buffers are client only and are registered once per mod load.
    /// </summary>
    public sealed class CadenceParticles : ModSystem
    {
        private static ParticleBuffer<CadenceSparkBehavior> _sparks;
        private static ParticleBuffer<CadenceMoteBehavior> _motes;

        public override bool IsLoadingEnabled(Mod mod) => !Main.dedServ;

        public override void Load()
        {
            _sparks = new ParticleBuffer<CadenceSparkBehavior>(768);
            ParticleManagerV3.RegisterUpdatable(_sparks);
            ParticleManagerV3.RegisterRenderable(Layer.BeforeDust, _sparks);

            _motes = new ParticleBuffer<CadenceMoteBehavior>(256);
            ParticleManagerV3.RegisterUpdatable(_motes);
            ParticleManagerV3.RegisterRenderable(Layer.BeforePlayers, _motes);
        }

        public override void Unload()
        {
            if (_sparks is not null)
            {
                ParticleManagerV3.UnregisterUpdatable(_sparks);
                ParticleManagerV3.UnregisterRenderable(Layer.BeforeDust, _sparks);
            }

            if (_motes is not null)
            {
                ParticleManagerV3.UnregisterUpdatable(_motes);
                ParticleManagerV3.UnregisterRenderable(Layer.BeforePlayers, _motes);
            }

            _sparks = null;
            _motes = null;
        }

        /// <summary>
        ///     Emits an additive spark. Colors are passed with a zero alpha channel, which is
        ///     how Particle Library expresses additive blending in an alpha blended buffer.
        /// </summary>
        public static void Spark(Vector2 position, Vector2 velocity, Color color, float size = 14f, int life = 26, float spin = 0f)
        {
            if (Main.dedServ || _sparks is null)
                return;

            Color additive = new(color.R, color.G, color.B, 0);
            _sparks.Create(new ParticleInfo(
                position.ToNumerics(),
                velocity.ToNumerics(),
                velocity.ToRotation(),
                new NumericsVector2(size, size * 0.55f),
                additive,
                life,
                spin));
        }

        /// <summary>Emits a slow, softly pulsing mote (used for the charged/ultimate ambience).</summary>
        public static void Mote(Vector2 position, Vector2 velocity, Color color, float size = 10f, int life = 90)
        {
            if (Main.dedServ || _motes is null)
                return;

            _motes.Create(new ParticleInfo(
                position.ToNumerics(),
                velocity.ToNumerics(),
                Main.rand.NextFloat(MathHelper.TwoPi),
                new NumericsVector2(size, size),
                new Color(color.R, color.G, color.B, 0),
                life));
        }

        /// <summary>Radial burst of sparks, the workhorse impact effect.</summary>
        public static void Burst(Vector2 position, Color color, int count = 10, float speed = 4f, float size = 14f, int life = 26)
        {
            if (Main.dedServ)
                return;

            count = NovaChordConfig.Instance.Count(count);
            for (int i = 0; i < count; i++)
            {
                Vector2 velocity = Main.rand.NextVector2CircularEdge(1f, 1f) * Main.rand.NextFloat(0.35f, 1f) * speed;
                Spark(position, velocity, color, size * Main.rand.NextFloat(0.7f, 1.25f), life + Main.rand.Next(-6, 8));
            }
        }
    }
}
