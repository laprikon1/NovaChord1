using Microsoft.Xna.Framework;
using NovaChord.Content.Buffs;
using Terraria.ModLoader;

namespace NovaChord.Common.Core
{
    /// <summary>The three "paths" the bow can be attuned to. Cycling is free and instant.</summary>
    public enum Attunement : byte
    {
        Glacial = 0,
        Voltaic = 1,
        Verdant = 2
    }

    public static class AttunementData
    {
        public const int Count = 3;

        /// <summary>Maximum stacks of a single mark before it "overflows".</summary>
        public const int MarkCap = 3;

        /// <summary>Lifetime of a mark, in ticks.</summary>
        public const int MarkDuration = 420;

        public static Color Primary(this Attunement attunement) => attunement switch
        {
            Attunement.Glacial => new Color(132, 232, 255),
            Attunement.Voltaic => new Color(190, 148, 255),
            _ => new Color(150, 240, 176)
        };

        public static Color Secondary(this Attunement attunement) => attunement switch
        {
            Attunement.Glacial => new Color(226, 250, 255),
            Attunement.Voltaic => new Color(255, 176, 240),
            _ => new Color(246, 214, 140)
        };

        public static int MarkBuff(this Attunement attunement) => attunement switch
        {
            Attunement.Glacial => ModContent.BuffType<GlacialMark>(),
            Attunement.Voltaic => ModContent.BuffType<VoltaicMark>(),
            _ => ModContent.BuffType<VerdantMark>()
        };

        /// <summary>Localization key of the attunement's display name.</summary>
        public static string NameKey(this Attunement attunement) => $"Mods.{NovaChord.ModName}.Attunements.{attunement}";

        public static Attunement Next(this Attunement attunement) => (Attunement)(((int)attunement + 1) % Count);
    }
}
