namespace NovaChord.Content.Buffs
{
    /// <summary>Verdant attunement mark. Overflow: healing bloom for the archer and a thorn burst.</summary>
    public sealed class VerdantMark : MarkBuff { }
}
