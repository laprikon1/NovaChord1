using Terraria;
using Terraria.ModLoader;

namespace NovaChord.Content.Buffs
{
    /// <summary>
    ///     Active during the Starfall Finale: +15% ranged damage and draws consume no ammo.
    ///     Applied by the server when the Finale begins; duration matches the Finale window.
    /// </summary>
    public sealed class Encore : ModBuff
    {
        public override void SetStaticDefaults()
        {
            Main.buffNoSave[Type] = true;
            Main.buffNoTimeDisplay[Type] = true;
        }

        public override void Update(Player player, ref int buffIndex)
        {
            player.GetDamage(DamageClass.Ranged) += 0.15f;
        }
    }
}
