using NovaChord.Common.Core;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace NovaChord.Content.Items
{
    /// <summary>
    ///     Encore Sigil — a post-Plantera accessory that leans into the cadence fantasy:
    ///     +12% ranged damage, a wider Perfect Draw window, 25% faster Finale gauge gain
    ///     and markedly better odds on the Finale's constellation draw.
    /// </summary>
    public sealed class EncoreSigil : ModItem
    {
        public override void SetDefaults()
        {
            Item.width = 28;
            Item.height = 30;
            Item.accessory = true;
            Item.value = Item.sellPrice(gold: 4);
            Item.rare = ItemRarityID.Yellow;
        }

        public override void UpdateAccessory(Player player, bool hideVisual)
        {
            player.GetModPlayer<CadencePlayer>().SigilEquipped = true;
            player.GetDamage(DamageClass.Ranged) += 0.12f;
        }

        public override void AddRecipes()
        {
            Recipe.Create(Type)
                .AddIngredient(ItemID.Ectoplasm, 6)
                .AddIngredient(ItemID.SoulofLight, 8)
                .AddIngredient(ItemID.FallenStar, 15)
                .AddTile(TileID.MythrilAnvil)
                .Register();
        }
    }
}
