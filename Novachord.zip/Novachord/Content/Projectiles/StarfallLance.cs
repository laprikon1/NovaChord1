using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Luminance.Core.Graphics;
using NovaChord.Common.Core;
using Terraria;
using Terraria.Audio;
using Terraria.GameContent;
using Terraria.ID;
using Terraria.ModLoader;

namespace NovaChord.Content.Projectiles
{
    /// <summary>
    ///     A starfall lance summoned by the Finale. Falls from the sky toward the cursor,
    ///     passing through tiles until it reaches the target point. Legendary draws home
    ///     in on nearby enemies after the pass.
    /// </summary>
    public sealed class StarfallLance : ModProjectile
    {
        private Vector2 Target => new(Projectile.ai[0], Projectile.ai[1]);
        private bool Homing => Projectile.ai[2] > 0f;

        public override void SetStaticDefaults()
        {
            Main.projFrames[Type] = 1;
            ProjectileID.Sets.TrailCacheLength[Type] = 12;
            ProjectileID.Sets.TrailingMode[Type] = 2;
        }

        public override void SetDefaults()
        {
            Projectile.width = 14;
            Projectile.height = 30;
            Projectile.aiStyle = 0;
            Projectile.friendly = true;
            Projectile.hostile = false;
            Projectile.DamageType = DamageClass.Ranged;
            Projectile.penetrate = 3;
            Projectile.timeLeft = 240;
            Projectile.tileCollide = false;
            Projectile.ignoreWater = true;
            Projectile.extraUpdates = 1;
        }

        public override void AI()
        {
            Vector2 toTarget = Target - Projectile.Center;
            if (!Projectile.tileCollide && (toTarget.Length() < 28f || Vector2.Dot(Projectile.velocity, toTarget) < 0f))
                Projectile.tileCollide = true;

            if (Homing && Projectile.tileCollide)
            {
                NPC best = null;
                float bestDist = 420f;
                foreach (NPC npc in Main.ActiveNPCs)
                {
                    if (!npc.CanBeChasedBy())
                        continue;
                    float dist = npc.Center.Distance(Projectile.Center);
                    if (dist < bestDist)
                    {
                        bestDist = dist;
                        best = npc;
                    }
                }
                if (best is not null)
                {
                    Vector2 desired = (best.Center - Projectile.Center).SafeNormalize(Vector2.UnitY) * Projectile.velocity.Length();
                    Projectile.velocity = Vector2.Lerp(Projectile.velocity, desired, 0.06f);
                }
            }

            Projectile.rotation = Projectile.velocity.ToRotation() + MathHelper.PiOver2;

            if (Main.rand.NextBool(2))
                CadenceParticles.Spark(Projectile.Center, -Projectile.velocity * 0.04f + Main.rand.NextVector2Circular(0.8f, 0.8f), new Color(255, 236, 170), 12f, 22);
        }

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            if (Main.netMode != NetmodeID.Server)
                CadenceParticles.Burst(target.Center, new Color(255, 224, 150), 12, 5f, 14f, 26);
        }

        public override void OnKill(int timeLeft)
        {
            if (Main.netMode != NetmodeID.Server)
            {
                CadenceParticles.Burst(Projectile.Center, new Color(255, 236, 170), 16, 5f, 16f, 30);
                SoundEngine.PlaySound(SoundID.Item89 with { Volume = 0.5f, Pitch = 0.3f }, Projectile.Center);
                CadenceCamera.Shake(Projectile.Center, 3f);
            }
        }

        public override bool PreDraw(ref Color lightColor)
        {
            Color gold = new(255, 224, 150);
            PrimitiveSettings settings = new(
                interpolant => 16f * (1f - interpolant),
                interpolant => gold * (1f - interpolant) * 0.8f,
                smoothen: true);
            PrimitiveRenderer.RenderTrail(TrailCenters(), settings);

            Texture2D texture = TextureAssets.Projectile[Type].Value;
            Vector2 origin = texture.Size() * 0.5f;
            Vector2 drawPos = Projectile.Center - Main.screenPosition;
            Main.spriteBatch.Draw(texture, drawPos, null, lightColor, Projectile.rotation, origin, 1f, SpriteEffects.None, 0f);
            Main.spriteBatch.Draw(texture, drawPos, null, gold * 0.6f, Projectile.rotation, origin, 1.08f, SpriteEffects.None, 0f);
            return false;
        }

        private IEnumerable<Vector2> TrailCenters()
        {
            Vector2 offset = Projectile.Size * 0.5f;
            foreach (Vector2 pos in Projectile.oldPos)
            {
                if (pos != Vector2.Zero)
                    yield return pos + offset;
            }
        }
    }
}
